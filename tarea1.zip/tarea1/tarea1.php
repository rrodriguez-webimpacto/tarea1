<?php
/**
* 2007-2020 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2020 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Tarea1 extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'tarea1';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Rafael Rodríguez Calvente';
        $this->need_instance = 1;

        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Tarea 1');
        $this->description = $this->l('Tarea 1 de iniciación');

        $this->confirmUninstall = $this->l('');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        Configuration::updateValue('TAREA1_LIVE_MODE', false);

        include(dirname(__FILE__).'/sql/install.php');

        return parent::install() &&
            $this->registerHook('displayHome');
    }

    public function uninstall()
    {
        Configuration::deleteByName('TAREA1_LIVE_MODE');

        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall();
    }

    public function getContent()
    {
        if (Configuration::get('myQuote') != '') {
            $this->context->smarty->assign('myQuote', Configuration::get('myQuote'));
        } else {
            Configuration::updateValue('myQuote', 'Introduce una frase de bienvenida . . .');
            $this->context->smarty->assign('myQuote', 'Introduce una frase de bienvenida . . .');
        }

        // If the user sent a new quote on the BackOffice
        if (Tools::isSubmit('boton')) {
            $quote = Tools::getValue('quote');

            // Validation
            if ($quote != '') {
                Configuration::updateValue('myQuote', $quote);
                $this->context->smarty->assign(
                    array(
                        'info' => 'ok',
                        'myQuote' => $quote
                    )
                );
            } else {
                $this->context->smarty->assign('info', 'fail');
            }
        }
        return $this->display(__FILE__, 'configure.tpl');
    }

    public function hookDisplayHome()
    {
        $this->context->controller->addJS($this->_path.'views/js/back.js');
        $this->context->controller->addCSS($this->_path.'views/css/back.css');

        $myQuote = Configuration::get('myQuote');
        $this->context->smarty->assign('myQuote', $myQuote);

        return $this->display(__FILE__, 'displayHome.tpl');
    }
}
